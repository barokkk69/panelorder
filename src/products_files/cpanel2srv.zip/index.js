const TelegramBot = require('node-telegram-bot-api');
const { Client } = require('ssh2');
const { exec } = require('child_process');
const { createCanvas, loadImage, registerFont } = require('canvas');
const moment = require('moment');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const fetch = require('node-fetch'); // Pastikan sudah install
//const owner = config.adminId;
const settings = require('./config');
const owner = settings.adminId;
const botToken = settings.token;
const adminfile = 'adminID.json';
const premiumUsersFile = 'premiumUsers.json';
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
const domain2 = settings.domainV2;
const plta2 = settings.pltaV2;
const pltc2 = settings.pltcV2;
const BOT_TOKEN = settings.token;
const CHANNEL_ID = settings.channelprib;

try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}
const bot = new TelegramBot(botToken, { polling: true });
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
}
const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
function getRuntime(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}

const parseDuration = (input) => {
  const match = input.match(/^(\d+)([smhdby])$/i);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  
  const unitToMs = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    b: 30 * 24 * 60 * 60 * 1000, // bulan
    y: 365 * 24 * 60 * 60 * 1000 // tahun
  };

  return value * (unitToMs[unit] || 0);
};

const allChats = new Set(); // Cache semua ID chat (private & group)

// Simpan semua ID chat yang pernah aktif
bot.on('message', (msg) => {
  allChats.add(msg.chat.id);
});

async function joinChat(link) {
  if (!link.startsWith("https://t.me/")) {
    throw new Error("❌ Link tidak valid.");
  }

  // Cek apakah link adalah link undangan atau username
  if (link.includes("joinchat") || link.match(/t\.me\/\+/)) {
    // Link invite: gunakan langsung
    return await bot.joinChat(link);
  } else {
    // Link username, ambil @username-nya
    const username = link.split("/").pop();
    return await bot.joinChat(`@${username}`);
  }
}

// File untuk logging
const logFile = 'bot.log';

// Fungsi untuk menulis log ke file dan console
function logToFileAndConsole(message) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage);
  fs.appendFileSync(logFile, logMessage);
}

// Scrape proxy dari sumber yang diberikan
async function scrapeProxies() {
  const proxySources = [
    'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=http&proxy_format=ipport&format=text&timeout=20000',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt',
    'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt',
    'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt',
    'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt',
    'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt',
    'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt',
    'https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt',
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt',
    'https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt',
    'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
    'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt',
    'https://raw.githubusercontent.com/HumayunShariarHimu/Proxy/main/Anonymous_HTTP_One.md',
    'https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/https.txt',
    'https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/http.txt',
    'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt',
    'https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/http/global/http_checked.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt'
  ];

  let proxies = [];

    // Hapus file proxy.txt lama
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
    logToFileAndConsole('proxy.txt lama berhasil dihapus');
  }
  
  for (const source of proxySources) {
    try {
      const response = await axios.get(source);
      proxies = proxies.concat(response.data.split('\n'));
    } catch (error) {
      logToFileAndConsole(`Error scraping proxies from ${source}: ${error.message}`);
    }
  }

  fs.writeFileSync('proxy.txt', proxies.join('\n'));
  logToFileAndConsole('Proxies successfully scraped and saved to proxy.txt');
}

// Mulai dengan scraping proxy saat bot dijalankan
scrapeProxies();
const nama = 'faze2high';
const author = 'faze2high';
// Informasi waktu mulai bot
const startTime = Date.now();
console.clear();

bot.sendMessage(owner, 'Hallo developer, Aku online ya !!');

//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Event Listener untuk Command /start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username || msg.from.first_name || '@faze2high';
    
    const menuText = `¡Bonjour, mon ami! ${sender} 👋
    
— Ptero Assisten 
🚀 PteroAssisten kini hadir untuk mempermudah proses membuat Pterodactyl server dengan cepat dan efisien

— Cara Menggunakan 
🛠️ Cukup dengan pencet tombol yang ada di bawah ini
    `;
    
     bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    // Kirim foto dengan teks dan button
    bot.sendPhoto(chatId, 'https://c.termai.cc/i97/X5h.jpg', {
        caption: menuText,
        reply_markup: {
            inline_keyboard: [
                [{ text: '🛠️Pᴀɴᴇʟ Rᴇꜱᴇʟʟᴇʀ', callback_data: 'menupanel' }, { text: '🛠️Pᴀɴᴇʟ Oᴡɴᴇʀ', callback_data: 'ownerp' }],
                [{ text: '📢Iɴғᴏ Sᴄʀɪᴘᴛ', url: 'https://t.me/faze2high' }],
                [{ text: '👤Oᴡɴᴇʀ Mᴇɴᴜ', callback_data: 'ownermenu' }, { text: 'Tᴜᴛᴏʀɪᴀʟ', callback_data: 'tutorial' }],                
                [{ text: '❯❯', callback_data: '2menu' }]
            ],
        },
    });
});
// PAYMENT MENU CO
bot.onText(/\/payment/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username || msg.from.first_name || '@faze2high';
    
    const menuText = `Haii @${sender}
    
💳 Silahkan pilih menu payment yang tersedia di bawah
    `;

    // Kirim foto dengan teks dan button
    bot.sendPhoto(chatId, 'https://c.termai.cc/i97/X5h.jpg', {
        caption: menuText,
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Dᴀɴᴀ', callback_data: 'paydana' }, { text: 'Oᴠᴏ', callback_data: 'payovo' }, { text: 'Gᴏᴘᴀʏ', callback_data: 'paygopay' }],
                [{ text: 'Qʀɪꜱ', callback_data: 'payqr' }],
                [{ text: 'Iɴғᴏ Sᴄʀɪᴘᴛ', url: 'https://t.me/faze2high' }],
            ],
        },
    });
});
       

// Event Listener untuk Callback Button
bot.on("callback_query", async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const senderId = callbackQuery.from.id;
    const id = callbackQuery.from.id;
    const senderName = callbackQuery.from.username ? `@${callbackQuery.from.username}` : `${senderId}`;
    const [action, formatedNumber] = callbackQuery.data.split(":");

    // Definisi variabel yang belum ada
    let whatsappStatus = true; // Ganti sesuai logic di kode utama
    let getOnlineDuration = () => "1h 23m"; // Placeholder function
    
        if (action === "menu") {        
            let ligma = `¡Bonjour, mon ami! ${senderName} 👋
    
— Ptero Assisten 
🚀 PteroAssisten kini hadir untuk mempermudah proses membuat Pterodactyl server dengan cepat dan efisien

— Cara Menggunakan 
🛠️ Cukup dengan pencet tombol yang ada di bawah ini
`;
            replyMarkup = {
        inline_keyboard: [
        [{ text: 'Pᴀɴᴇʟ Rᴇꜱᴇʟʟᴇʀ', callback_data: 'menupanel' }, { text: 'Pᴀɴᴇʟ Oᴡɴᴇʀ', callback_data: 'ownerp' }],
        [{ text: 'Iɴғᴏ Sᴄʀɪᴘᴛ', url: 'https://t.me/faze2high' }],
        [{ text: 'Oᴡɴᴇʀ Mᴇɴᴜ', callback_data: 'ownermenu' }, { text: 'Tᴜᴛᴏʀɪᴀʟ', callback_data: 'tutorial' }],                  
        [{ text: '❯❯', callback_data: '2menu' }],      
      ]
      };
    
    bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });   
} else if (action === "menupanel") {
            let ligma = `(🍁) Panelmenu

-# Cᴏᴍᴍᴀɴᴅꜱ
▢ /1gb
▢ /2gb
▢ /3gb
▢ /4gb
▢ /5gb
▢ /6gb
▢ /7gb
▢ /8gb
▢ /9gb
▢ /10gb
▢ /11gb
▢ /unli
▢ /cadmin
▢ /listserver
▢ /listadmin
▢ /clearserver
▢ /listuser
▢ /clearuser
▢ /deladmin
▢ /delpanel
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });      
        } else if (action === "2menu") {
            let ligma = `¡Bonjour, mon ami! ${senderName} 👋
    
— Ptero Assisten 
🚀 PteroAssisten kini hadir untuk mempermudah proses membuat Pterodactyl server dengan cepat dan efisien

— Cara Menggunakan 
🛠️ Cukup dengan pencet tombol yang ada di bawah ini
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "🖇️ Oᴛʜᴇʀ Mᴇɴᴜ", callback_data: "othermenu" }, { text: "📡 ɢʀᴏᴜᴘ ᴍᴇɴᴜ", callback_data: "groupmenu" }],
        [{ text: "❮❮", callback_data: "menu" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });      
         } else if (action === "othermenu") {
            let ligma = `(🍁) Othermenu

-# Cᴏᴍᴍᴀɴᴅꜱ
▢ /send
▢ /spam
▢ /spamht
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });      
        
        } else if (action === "groupmenu") {
            let ligma = `(🍁) Groupmenu

-# Cᴏᴍᴍᴀɴᴅꜱ
▢ /ban
▢ /tmute
▢ /promote
▢ /demote
▢ /zombies
▢ /allmember
▢ /hidetag
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });      
  
        } else if (action === "ownermenu") {
            let ligma = `
\`\`\`(🍁)Ownermenu
  
-# Oᴡɴᴇʀ Cᴏᴍᴍᴀɴᴅꜱ
▢ /addprem
▢ /delprem
▢ /addowner
▢ /delowner
▢ /bcall
▢ /gcast
▢ /del
▢ /payment
▢ /upch
\`\`\`
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }, { text: "[ Pᴀʏᴍᴇɴᴛ ]", callback_data: "dpay" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });     
        
        } else if (action === "myid") {
            let ligma = `
(🍁)Haii ${senderName}
  
👤 ID Telegram Kamu : ${id}
🍁 Full Name Kamu : ${senderName}
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }], 
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });     
        
} else if (action === "ownerp") {
            let ligma = `
(🍁) Panelmenu

-# Oᴡɴᴇʀ Cᴏᴍᴍᴀɴᴅꜱ
▢ /c1gb
▢ /c2gb
▢ /c3gb
▢ /c4gb
▢ /c5gb
▢ /c6gb
▢ /c7gb
▢ /c8gb
▢ /c9gb
▢ /c10gb
▢ /1c1gb
▢ /cunli
▢ /cadp
▢ /listpanel
▢ /listadp
▢ /listusr
▢ /clearsrv
▢ /deladp
▢ /delsrv
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });                         
        
        } else if (action === "paygo") {
            let ligma = `Haii ${senderName} 👋
Berikut adalah payment Gopay yang tersedia pada bot.            

Nᴏᴍᴏʀ : 082280623562
Aᴛᴀꜱ Nᴀᴍᴀ : Na****

[ ! ] Mᴏʜᴏɴ ꜱᴇʀᴛᴀᴋᴀɴ ʙᴜᴋᴛɪ ᴛʀᴀɴꜱꜰᴇʀ ᴊɪᴋᴀ ꜱᴜᴅᴀʜ ᴛʀᴀɴꜱꜰᴇʀ ᴋᴇ ʀᴇᴋᴇɴɪɴɢ ᴏᴡɴᴇʀ.
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "dpay" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });     
        
        } else if (action === "payovo") {
            let ligma = `Haii ${senderName} 👋
Berikut adalah payment Ovo yang tersedia pada bot.            

Nᴏᴍᴏʀ : 082280623562
Aᴛᴀꜱ Nᴀᴍᴀ : Na****

[ ! ] Mᴏʜᴏɴ ꜱᴇʀᴛᴀᴋᴀɴ ʙᴜᴋᴛɪ ᴛʀᴀɴꜱꜰᴇʀ ᴊɪᴋᴀ ꜱᴜᴅᴀʜ ᴛʀᴀɴꜱꜰᴇʀ ᴋᴇ ʀᴇᴋᴇɴɪɴɢ ᴏᴡɴᴇʀ.
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "dpay" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });     
        
} else if (action === "payqr") {
            let ligma = `Haii ${senderName} 👋
Jɪᴋᴀ ɪɴɢɪɴ ᴛʀᴀɴꜱꜰᴇʀ ᴠɪᴀ Qʀɪꜱ Aʟʟᴘᴀʏᴍᴇɴᴛ ᴍᴏʜᴏɴ ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ʏᴀɴɢ ᴀᴅᴀ ᴘᴀᴅᴀ ᴛᴏᴍʙᴏʟ

[ ! ] Mᴏʜᴏɴ ꜱᴇʀᴛᴀᴋᴀɴ ʙᴜᴋᴛɪ ᴛʀᴀɴꜱꜰᴇʀ ᴊɪᴋᴀ ꜱᴜᴅᴀʜ ᴛʀᴀɴꜱꜰᴇʀ ᴋᴇ ʀᴇᴋᴇɴɪɴɢ ᴏᴡɴᴇʀ.
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "dpay" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });     
        
        } else if (action === "paydana") {
            let ligma = `Haii ${senderName} 👋
Berikut adalah payment Dana yang tersedia pada bot.            

Nᴏᴍᴏʀ : 082280623562
Aᴛᴀꜱ Nᴀᴍᴀ : Na****

[ ! ] Mᴏʜᴏɴ ꜱᴇʀᴛᴀᴋᴀɴ ʙᴜᴋᴛɪ ᴛʀᴀɴꜱꜰᴇʀ ᴊɪᴋᴀ ꜱᴜᴅᴀʜ ᴛʀᴀɴꜱꜰᴇʀ ᴋᴇ ʀᴇᴋᴇɴɪɴɢ ᴏᴡɴᴇʀ.
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Bᴀᴄᴋ ]", callback_data: "dpay" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });     
            
           } else if (action === "dpay") {
            let ligma = `¡Haii ${senderName}
    
💳 Silahkan pilih menu payment yang tersedia di bawah
`;
replyMarkup = {
        inline_keyboard: [
        [{ text: 'Dᴀɴᴀ', callback_data: 'paydana' }, { text: 'Oᴠᴏ', callback_data: 'payovo' }, { text: 'Gᴏᴘᴀʏ', callback_data: 'paygo' }],
        [{ text: 'Qʀɪꜱ', callback_data: 'payqr' }],
        [{ text: 'Iɴғᴏ Sᴄʀɪᴘᴛ', url: 'https://t.me/+https://t.me/faze2high' }],
      ]
      };
           

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });      
                      
        } else if (action === "tutorial") {
            let ligma = `✨ Cara Membuat Panel Unlimited ✨
Silakan kirim perintah berikut di chat bot:
/ram namapanelgram

\`\`\`Contoh:
/unli MyPanel,123456789
\`\`\`
Bot akan memproses dan mengirimkan detail panel secara otomatis.

Belum tahu ID Telegram kamu?
Klik tombol Cek ID di bawah ini untuk mengetahuinya!

Jika ada kendala, silakan hubungi admin.
Terima kasih telah menggunakan layanan kami!
`

            replyMarkup = {
        inline_keyboard: [
        [{ text: "[ Cᴇᴋ ID ]", callback_data: "myid" }, { text: "[ Bᴀᴄᴋ ]", callback_data: "menu" }],
        [{ text: "[ Cᴏɴᴛᴀᴄᴛ ]", url: "https://t.me/faze2high" }]        
      ]
      };
    

     bot.editMessageMedia(
      {
        type: "photo",
        media: "https://c.termai.cc/i97/X5h.jpg",
        caption: ligma,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
        });   
       } else {
            bot.sendMessage(chatId, "❌ Unknown action.");
        };
    });
    
    // === Fungsi kirim notifikasi ke owner ===
async function notifyOwner(msg, user, password) {
  const creator = msg.from.username
    ? `@${msg.from.username}`
    : `${msg.from.first_name} (${msg.from.id})`;

  const text = `
🆕 *Akun Panel Baru Dibuat!*

👤 Dibuat oleh: ${creator}
📦 Username Panel: \`${user.username}\`
🔑 Password: \`${password}\`
📧 Email: ${user.email}
⏰ Waktu: ${new Date().toLocaleString()}
`;

  try {
    await bot.sendMessage(owner, text, { parse_mode: "Markdown" });
    console.log("Notifikasi owner terkirim.");
  } catch (err) {
    console.error("Gagal kirim notifikasi:", err.message);
  }
}
    
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//===================MENU CPANEL===≈====≈============//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//DONE
bot.onText(/\/done (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1].split(',');
  
  if (input.length < 3) {
    return bot.sendMessage(chatId, '⚠️ Format salah!\n\nContoh:\n`/done WebPanelV4,20000,Dana`', { parse_mode: 'Markdown' });
  }

  const [item, price, payment] = input.map(str => str.trim());

  const doneText = `
✨ *TRANSAKSI SELESAI!*
━━━━━━━━━━━━━━━━━━
🛍️ *Produk:* ${item}
💸 *Harga:* Rp${price}
💳 *Metode Pembayaran:* ${payment}
━━━━━━━━━━━━━━━━━━
✅ Terima kasih sudah melakukan transaksi.
Untuk bantuan lebih lanjut, silakan klik tombol di bawah ini.
`;

  bot.sendMessage(chatId, doneText, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [[
        { text: 'Hubungi Admin', url: 'https://t.me/faze2high' }
      ]]
    }
  });
});

// CLEAR SERVER
bot.onText(/^\/clearserver (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Validasi premium
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(userId));
  if (!isPremium) {
    return bot.sendMessage(chatId, '❌ Fitur ini hanya untuk pengguna premium.');
  }

  const excludedIds = match[1]
    .split(',')
    .map((id) => id.trim())
    .filter((id) => id.length > 0);

  bot.sendMessage(chatId, `⛔ ID yang dilewati: ${excludedIds.join(', ')}`);

  try {
    const response = await fetch(`${domain}/api/application/servers`, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${plta}`,
      },
    });

    const res = await response.json();
    const servers = res.data;

    if (!servers || servers.length === 0) {
      return bot.sendMessage(chatId, '⚠️ Tidak ada server yang ditemukan.');
    }

    for (const server of servers) {
      const serverId = String(server.attributes.id);

      if (excludedIds.includes(serverId)) {
        await bot.sendMessage(chatId, `➡️ Lewati server ID: ${serverId}`);
        continue;
      }

      const deleteRes = await fetch(`${domain}/api/application/servers/${serverId}`, {
        method: 'DELETE',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${pltc}`,
        },
      });

      if (deleteRes.ok) {
        await bot.sendMessage(chatId, `✅ Berhasil hapus server: ${serverId}`);
      } else {
        const errText = await deleteRes.text();
        await bot.sendMessage(chatId, `❌ Gagal hapus server ID: ${serverId}\n${errText}`);
      }
    }

    await bot.sendMessage(chatId, '✔️ Proses penghapusan selesai.');
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${err.message}`);
  }
});
bot.onText(/^\/clearsrv (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Validasi premium
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(userId));
  if (!isPremium) {
    return bot.sendMessage(chatId, '❌ Fitur ini hanya untuk pengguna premium.');
  }

  const excludedIds = match[1]
    .split(',')
    .map((id) => id.trim())
    .filter((id) => id.length > 0);

  bot.sendMessage(chatId, `⛔ ID yang dilewati: ${excludedIds.join(', ')}`);

  try {
    const response = await fetch(`${domain2}/api/application/servers`, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${plta2}`,
      },
    });

    const res = await response.json();
    const servers = res.data;

    if (!servers || servers.length === 0) {
      return bot.sendMessage(chatId, '⚠️ Tidak ada server yang ditemukan.');
    }

    for (const server of servers) {
      const serverId = String(server.attributes.id);

      if (excludedIds.includes(serverId)) {
        await bot.sendMessage(chatId, `➡️ Lewati server ID: ${serverId}`);
        continue;
      }

      const deleteRes = await fetch(`${domain2}/api/application/servers/${serverId}`, {
        method: 'DELETE',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${pltc2}`,
        },
      });

      if (deleteRes.ok) {
        await bot.sendMessage(chatId, `✅ Berhasil hapus server: ${serverId}`);
      } else {
        const errText = await deleteRes.text();
        await bot.sendMessage(chatId, `❌ Gagal hapus server ID: ${serverId}\n${errText}`);
      }
    }

    await bot.sendMessage(chatId, '✔️ Proses penghapusan selesai.');
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${err.message}`);
  }
});
// CLEAR USER
bot.onText(/\/clearuser/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah yang akses owner
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));

  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  try {
    const res = await fetch(`${domain}/api/application/users`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      }
    });

    const data = await res.json();
    const users = data.data;

    if (!users || users.length < 1) {
      return bot.sendMessage(chatId, "Tidak ada user yang ditemukan.");
    }

    let deleted = 0;
    for (const user of users) {
      const { id, username, root_admin } = user.attributes;
      if (root_admin === true) continue; // Lewati jika admin

      const del = await fetch(`${domain}/api/application/users/${id}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${plta}`
        }
      });

      if (del.ok) {
        deleted++;
        await bot.sendMessage(chatId, `✅ Berhasil hapus user: ${username} (ID: ${id})`);
      } else {
        const err = await del.text();
        await bot.sendMessage(chatId, `❌ Gagal hapus user ID: ${id} - ${err}`);
      }
    }

    if (deleted === 0) {
      bot.sendMessage(chatId, "Tidak ada user yang berhasil dihapus.");
    } else {
      bot.sendMessage(chatId, `Selesai menghapus ${deleted} user yang bukan admin.`);
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});

bot.onText(/\/clearusr/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah yang akses owner
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));

  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  try {
    const res = await fetch(`${domain2}/api/application/users`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      }
    });

    const data = await res.json();
    const users = data.data;

    if (!users || users.length < 1) {
      return bot.sendMessage(chatId, "Tidak ada user yang ditemukan.");
    }

    let deleted = 0;
    for (const user of users) {
      const { id, username, root_admin } = user.attributes;
      if (root_admin === true) continue; // Lewati jika admin

      const del = await fetch(`${domain2}/api/application/users/${id}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${plta2}`
        }
      });

      if (del.ok) {
        deleted++;
        await bot.sendMessage(chatId, `✅ Berhasil hapus user: ${username} (ID: ${id})`);
      } else {
        const err = await del.text();
        await bot.sendMessage(chatId, `❌ Gagal hapus user ID: ${id} - ${err}`);
      }
    }

    if (deleted === 0) {
      bot.sendMessage(chatId, "Tidak ada user yang berhasil dihapus.");
    } else {
      bot.sendMessage(chatId, `Selesai menghapus ${deleted} user yang bukan admin.`);
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});
// LIST USER
bot.onText(/\/listuser/, async (msg) => {
  const chatId = msg.chat.id;
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
          ]
        ]
      }
    });
    return;
  }

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`
      }
    });

    const json = await response.json();
    const users = json.data;
    if (!users || users.length === 0) return bot.sendMessage(chatId, "Tidak ada user yang terdaftar di panel.");

    let teks = `📋 *List User Panel:*\n\n`;
    for (let i of users) {
      const { id, username, root_admin, first_name } = i.attributes;
      const adminStatus = root_admin ? "⭐" : "❌";
      teks += `🆔 *${id}* - *${username}*\n👤 ${first_name} ${adminStatus}\n\n`;
    }

    bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, "Gagal mengambil data user panel.");
  }
});
bot.onText(/\/listusr/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah yang akses owner
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));

  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  try {
    const res = await fetch(`${domain2}/api/application/users`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      }
    });

    const data = await res.json();
    const users = data.data;

    if (!users || users.length < 1) {
      return bot.sendMessage(chatId, "Tidak ada user panel.");
    }

    let teks = `📋 *Daftar Pengguna Panel:*\nTotal: ${users.length} user\n\n`;
    for (const user of users) {
      const { id, username, email, root_admin, created_at } = user.attributes;
      teks += `🆔 *ID:* ${id}\n👤 *Username:* ${username}\n📧 *Email:* ${email}\n⭐ *Admin:* ${root_admin ? "✅" : "❌"}\n📆 *Created:* ${created_at.split("T")[0]}\n\n`;
    }

    bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});

// DELETE PANEL
bot.onText(/\/delpanel (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah pengguna adalah admin
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));
  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Admin/Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  const panelId = match[1].trim();
  if (!panelId) {
    return bot.sendMessage(chatId, "Contoh penggunaan: `/delpanel 123`", { parse_mode: "Markdown" });
  }

  try {
    const response = await fetch(`${domain}/api/application/servers/${panelId}`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${plta}`
      }
    });

    if (response.ok) {
      bot.sendMessage(chatId, `✅ Berhasil menghapus server dengan ID: ${panelId}`);
    } else {
      const err = await response.text();
      bot.sendMessage(chatId, `❌ Gagal menghapus server ID: ${panelId}\nError: ${err}`);
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});

bot.onText(/\/delsrv (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah pengguna adalah admin
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));
  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Admin/Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  const panelId = match[1].trim();
  if (!panelId) {
    return bot.sendMessage(chatId, "Contoh penggunaan: `/delpanel 123`", { parse_mode: "Markdown" });
  }

  try {
    const response = await fetch(`${domain2}/api/application/servers/${panelId}`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${plta2}`
      }
    });

    if (response.ok) {
      bot.sendMessage(chatId, `✅ Berhasil menghapus server dengan ID: ${panelId}`);
    } else {
      const err = await response.text();
      bot.sendMessage(chatId, `❌ Gagal menghapus server ID: ${panelId}\nError: ${err}`);
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});
// DELETE ADMIN
bot.onText(/\/deladmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah user termasuk admin
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));
  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Admin/Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  const adminId = match[1].trim();
  if (!adminId || isNaN(adminId)) {
    return bot.sendMessage(chatId, 'Contoh penggunaan: `/deladmin 123`', { parse_mode: 'Markdown' });
  }

  try {
    const del = await fetch(`${domain}/api/application/users/${adminId}`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${plta}`
      }
    });

    if (del.ok) {
      bot.sendMessage(chatId, `✅ Berhasil menghapus admin dengan ID: ${adminId}`);
    } else {
      const errorText = await del.text();
      bot.sendMessage(chatId, `❌ Gagal menghapus admin ID: ${adminId}\nError: ${errorText}`);
    }
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});

bot.onText(/\/deladp (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Cek apakah user termasuk admin
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));
  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Admin/Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  const adminId = match[1].trim();
  if (!adminId || isNaN(adminId)) {
    return bot.sendMessage(chatId, 'Contoh penggunaan: `/deladmin 123`', { parse_mode: 'Markdown' });
  }

  try {
    const del = await fetch(`${domain2}/api/application/users/${adminId}`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${plta2}`
      }
    });

    if (del.ok) {
      bot.sendMessage(chatId, `✅ Berhasil menghapus admin dengan ID: ${adminId}`);
    } else {
      const errorText = await del.text();
      bot.sendMessage(chatId, `❌ Gagal menghapus admin ID: ${adminId}\nError: ${errorText}`);
    }
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `Terjadi kesalahan: ${err.message}`);
  }
});
// LIST ADMIN
bot.onText(/\/listadmin/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
    // Cek apakah user termasuk admin
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));
  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Admin/Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`
      }
    });

    const json = await response.json();
    const users = json.data;
    const admins = users.filter(user => user.attributes.root_admin);

    if (admins.length === 0) return bot.sendMessage(chatId, "Tidak ada admin yang terdaftar di panel.");

    let teks = `⭐ *List Admin Panel:*\n\n`;
    for (let admin of admins) {
      const { id, username, first_name, created_at } = admin.attributes;
      teks += `🆔 *${id}* - *${username}*\n👤 ${first_name} ⭐\n🕰️ Dibuat: ${created_at.split("T")[0]}\n\n`;
    }

    bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, "Gagal mengambil data admin dari panel.");
  }
});

bot.onText(/\/listadp/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
    // Cek apakah user termasuk admin
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));
  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Admin/Owner.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Hubungi Admin', url: 'https://t.me/faze2high' }]]
      }
    });
  }

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta2}`
      }
    });

    const json = await response.json();
    const users = json.data;
    const admins = users.filter(user => user.attributes.root_admin);

    if (admins.length === 0) return bot.sendMessage(chatId, "Tidak ada admin yang terdaftar di panel.");

    let teks = `⭐ *List Admin Panel:*\n\n`;
    for (let admin of admins) {
      const { id, username, first_name, created_at } = admin.attributes;
      teks += `🆔 *${id}* - *${username}*\n👤 ${first_name} ⭐\n🕰️ Dibuat: ${created_at.split("T")[0]}\n\n`;
    }

    bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, "Gagal mengambil data admin dari panel.");
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

bot.onText(/\/1gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '1gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '1024';
  const cpu = '30';
  const disk = '1024';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
    
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/2gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '2gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '2048';
  const cpu = '60';
  const disk = '2048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/3gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '3gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '3072';
  const cpu = '90';
  const disk = '3072';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/unli (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'unlimited';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '0';
  const cpu = '0';
  const disk = '0';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/11gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '11gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '11000';
  const cpu = '290';
  const disk = '10000';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/10gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '10gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '10000';
  const cpu = '290';
  const disk = '10000';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/9gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '9gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '9048';
  const cpu = '260';
  const disk = '9048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/4gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '4gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '4048';
  const cpu = '110';
  const disk = '4048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/8gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '8gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '8048';
  const cpu = '230';
  const disk = '8048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/7gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '7gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '7048';
  const cpu = '200';
  const disk = '7048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/5gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '5gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '5048';
  const cpu = '140';
  const disk = '5048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/6gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + '6gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '6048';
  const cpu = '170';
  const disk = '6048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

??  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

//OWNER
bot.onText(/\/c1gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c1gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '1024';
  const cpu = '30';
  const disk = '1024';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/c2gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c2gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '2048';
  const cpu = '60';
  const disk = '2048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/c3gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c3gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '3072';
  const cpu = '90';
  const disk = '3072';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/cunli (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'unlimited';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '0';
  const cpu = '0';
  const disk = '0';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/c11gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c11gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '11000';
  const cpu = '290';
  const disk = '10000';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/c10gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c10gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '10000';
  const cpu = '290';
  const disk = '10000';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/c9gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c9gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '9048';
  const cpu = '260';
  const disk = '9048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/c4gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c4gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '4048';
  const cpu = '110';
  const disk = '4048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/c8gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c8gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '8048';
  const cpu = '230';
  const disk = '8048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/c7gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c7gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '7048';
  const cpu = '200';
  const disk = '7048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/c5gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c5gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '5048';
  const cpu = '140';
  const disk = '5048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤  Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/c6gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));

  if (!isPremium) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendMessage(chatId, 'Pᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ, ʜᴜʙᴜɴɢɪ ᴀᴅᴍɪɴ ꜱᴀʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ᴜꜱᴇʀꜱ ᴘʀᴇᴍɪᴜᴍ...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
    return;
  }

  // Parsing input: namapanel,idtelegram atau hanya namapanel
  const [username, targetId] = input.includes(',') ? input.split(',') : [input, msg.from.id];
  const name = username + 'c6gb';
  const email = `${username}@fazeganteng.com`;
  const randomNumber = Math.floor(Math.random() * 10000); 
const fourDigits = String(randomNumber).padStart(4, '0');

const password = `${username}${fourDigits}`;

console.log(password);

  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '6048';
  const cpu = '170';
  const disk = '6048';
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user, server;

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const data = await response.json();

    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }

    user = data.attributes;

    const response2 = await fetch(`${domain2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const data2 = await response2.json();
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
    return;
  }

  const datap = `Haii @${targetId}
Berikut data akun panel anda

👤 Username : ${user.username}
🔑 Password : ${password}

⛔ Syarat Dan Ketentuan !!
• Jaga data panel anda!!
• Jangan memakai script ddos
• Jangan sebar link panel
• Masa berlaku panel ini adalah 1bulan

Gunakan panel anda dengan bijak.
`;

  if (akunlo) {
    bot.sendPhoto(targetId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datap,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Panel berhasil dikirim ke ${targetId == msg.from.id ? 'anda' : `user ${targetId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } else {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// createadmin
bot.onText(/\/cadmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));

  if (!isAdmin) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Owner. Hubungi Admin untuk akses.', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
  }

  const commandParams = match[1].split(',');

  const panelName = commandParams[0].trim();
  const telegramId = commandParams.length > 1 ? commandParams[1].trim() : userId;
  // bikin angka random 0 - 9999
const randomNumber = Math.floor(Math.random() * 10000);

// pad jadi 4 digit, misal 0007, 0932, dst
const fourDigits = String(randomNumber).padStart(4, '0');

// gabungkan dengan panelName
const password = panelName + fourDigits;

console.log(password);

  if (!panelName) {
    return bot.sendMessage(chatId, 'Format Salah!\nContoh:\n- /cadmin namapanel\n- /cadmin namapanel,idtelegram');
  }

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: `${panelName}@fazeganteng.com`,
        username: panelName,
        first_name: panelName,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: password
      })
    });

    const data = await response.json();

    if (data.errors) {
      return bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
    }

    const user = data.attributes;

    const userInfo = `
Type: User Admin
📡 ID: ${user.id}
👤 USERNAME: ${user.username}
🕰️ CREATED AT: ${user.created_at}
    `.trim();    
    
    bot.sendMessage(chatId, userInfo);

    // Escape untuk MarkdownV2
    function escapeMarkdownV2(text) {
      return text.replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&');
    }

    const safeUsername = escapeMarkdownV2(panelName);
    const safePassword = escapeMarkdownV2(password);

    let datanya = `📡 Informasi Login

👤 Username: ||${safeUsername}||
🔑 Password: ||${safePassword}||

\`\`\`
📌 Aturan Penggunaan:

1. Jangan mengubah konfigurasi inti tanpa izin pemilik panel.
2. Dilarang menghapus server, user, atau file penting lainnya.
3. Gunakan akses hanya untuk keperluan administrasi ringan.
4. Tidak diperkenankan membagikan akun ini kepada siapa pun.
5. Laporkan masalah atau bug yang ditemukan kepada admin utama.
Pelanggaran terhadap aturan ini dapat mengakibatkan pencabutan akses tanpa pemberitahuan.

Terima kasih atas kerjasamanya!
— Tim Admin Panel
\`\`\`
`;
     
     bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
     
    bot.sendPhoto(telegramId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datanya,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Data admin berhasil dikirim ke ${telegramId == msg.from.id ? 'anda' : `user ${telegramId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } catch (err) {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

bot.onText(/\/cadp (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(userId));

  if (!isAdmin) {
  	bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    return bot.sendMessage(chatId, 'Perintah ini hanya untuk Owner. Hubungi Admin untuk akses.', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
  }

  const commandParams = match[1].split(',');

  const panelName = commandParams[0].trim();
  const telegramId = commandParams.length > 1 ? commandParams[1].trim() : userId;
  // bikin angka random 0 - 9999
const randomNumber = Math.floor(Math.random() * 10000);

// pad jadi 4 digit, misal 0007, 0932, dst
const fourDigits = String(randomNumber).padStart(4, '0');

// gabungkan dengan panelName
const password = panelName + fourDigits;

console.log(password);

  if (!panelName) {
    return bot.sendMessage(chatId, 'Format Salah!\nContoh:\n- /cadmin namapanel\n- /cadmin namapanel,idtelegram');
  }

  try {
    const response = await fetch(`${domain2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta2}`
      },
      body: JSON.stringify({
        email: `${panelName}@fazeganteng.com`,
        username: panelName,
        first_name: panelName,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: password
      })
    });

    const data = await response.json();

    if (data.errors) {
      return bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
    }

    const user = data.attributes;

    const userInfo = `
Type: User Admin
📡 ID: ${user.id}
👤 USERNAME: ${user.username}
🕰️ CREATED AT: ${user.created_at}
    `.trim();    
    
    bot.sendMessage(chatId, userInfo);

    // Escape untuk MarkdownV2
    function escapeMarkdownV2(text) {
      return text.replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&');
    }

    const safeUsername = escapeMarkdownV2(panelName);
    const safePassword = escapeMarkdownV2(password);

    let datanya = `📡 Informasi Login

👤 Username: ||${safeUsername}||
🔑 Password: ||${safePassword}||

\`\`\`
📌 Aturan Penggunaan:

1. Jangan mengubah konfigurasi inti tanpa izin pemilik panel.
2. Dilarang menghapus server, user, atau file penting lainnya.
3. Gunakan akses hanya untuk keperluan administrasi ringan.
4. Tidak diperkenankan membagikan akun ini kepada siapa pun.
5. Laporkan masalah atau bug yang ditemukan kepada admin utama.
Pelanggaran terhadap aturan ini dapat mengakibatkan pencabutan akses tanpa pemberitahuan.

Terima kasih atas kerjasamanya!
— Tim Admin Panel
\`\`\`
`;
    
    bot.sendMessage(chatId, "⌛")
     new Promise(resolve => setTimeout(resolve, 1000));
    bot.sendPhoto(telegramId, 'https://c.termai.cc/i97/X5h.jpg', {
      caption: datanya,
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Dᴏᴍᴀɪɴ', url: `${domain2}` }],
          [
            { text: '📢 Cʜᴀɴɴᴇʟ Dᴇᴠᴇʟᴏᴘ', url: 'https://t.me/faze2high' },
            { text: '🛠️ Dᴇᴠᴇʟᴏᴘᴇʀ', url: 'https://t.me/faze2high' }
          ],
          [{ text: '🍁 Iɴꜰᴏ Pᴀɴᴇʟ', url: 'https://t.me/faze2high' }]
        ]
      }
    });

    bot.sendMessage(chatId, `✅ Data admin berhasil dikirim ke ${telegramId == msg.from.id ? 'anda' : `user ${telegramId}`}`);
        
        // === Kirim notifikasi ke owner ===
    await notifyOwner(msg, user, password);
    
  } catch (err) {
    bot.sendMessage(chatId, '❌ Gagal membuat data panel. Silakan coba lagi.');
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listsrv
bot.onText(/\/listserver/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;   
// Check if the user is the Owner
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
                    ]
                ]
            }
        });
        return;
    }
    let page = 1; // Mengubah penggunaan args[0] yang tidak didefinisikan sebelumnya
    try {
        let f = await fetch(`${domain}/api/application/servers?page=${page}`, { // Menggunakan backticks untuk string literal
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let servers = res.data;
        let messageText = "Daftar server aktif yang dimiliki:\n\n";
        for (let server of servers) {
            let s = server.attributes;

            let f3 = await fetch(`${domain}/api/client/servers/${s.uuid.split('-')[0]}/resources`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${pltc}`
                }
            });
            let data = await f3.json();
            let status = data.attributes ? data.attributes.current_state : s.status;

            messageText += `ID Server: ${s.id}\n`;
            messageText += `Nama Server: ${s.name}\n`;
            messageText += `Status: ${status}\n\n`;
        }

        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});

bot.onText(/\/listpanel/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;   
// Check if the user is the Owner
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
                    ]
                ]
            }
        });
        return;
    }
    let page = 1; // Mengubah penggunaan args[0] yang tidak didefinisikan sebelumnya
    try {
        let f = await fetch(`${domain2}/api/application/servers?page=${page}`, { // Menggunakan backticks untuk string literal
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta2}`
            }
        });
        let res = await f.json();
        let servers = res.data;
        let messageText = "Daftar server aktif yang dimiliki:\n\n";
        for (let server of servers) {
            let s = server.attributes;

            let f3 = await fetch(`${domain2}/api/client/servers/${s.uuid.split('-')[0]}/resources`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${pltc2}`
                }
            });
            let data = await f3.json();
            let status = data.attributes ? data.attributes.current_state : s.status;

            messageText += `ID Server: ${s.id}\n`;
            messageText += `Nama Server: ${s.name}\n`;
            messageText += `Status: ${status}\n\n`;
        }

        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});

bot.onText(/^\/bcall(?:\s+([\s\S]+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
// Check if the user is the Owner
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
  // Hanya owner yang bisa broadcast
  if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
                    ]
                ]
            }
        });
        return;
    }

  const text = match[1];
  if (!text) return bot.sendMessage(chatId, "⚠️ Masukkan teks yang ingin dibroadcast.\n\nContoh:\n<b>/bcall Halo semua!</b>", {
    parse_mode: "HTML"
  });

  bot.sendMessage(chatId, `📢 Mengirim broadcast ke ${allChats.size} chat...`);

  let success = 0, failed = 0;
  for (const id of allChats) {
    try {
      await bot.sendMessage(id, `📢 Broadcast:\n\n${text}`);
      success++;
    } catch (e) {
      failed++;
    }

    // Delay agar tidak overload
    await new Promise(r => setTimeout(r, 300)); // 0.3 detik
  }
   let doneb = `⌭  ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴛᴇxᴛ ᴅᴏɴᴇ
   
⌭  sᴜᴄᴄᴇs ${success} ɢʀᴏᴜᴘ
⌭  ғᴀɪʟᴇᴅ ${failed} ɢʀᴏᴜᴘ

ᣃ࿈ ʙʀᴏᴀᴅᴄᴀꜱᴛ ʙʏ @faze2high ࿈ᣄ
` 

  bot.sendMessage(chatId, doneb)
});

// Perintah untuk broadcast via forward
bot.onText(/\/gcast/, async (msg) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  // Load daftar admin dari file
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(fromId));

  if (!isAdmin) {
    return bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }]
        ]
      }
    });
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '❗ Silakan reply ke pesan yang ingin di-broadcast.');
  }

  let success = 0;
  let failed = 0;

  for (const id of allChats) {
    try {
      await bot.forwardMessage(id, chatId, msg.reply_to_message.message_id);
      success++;
    } catch (err) {
      failed++;
      console.log(`❌ Gagal kirim ke ${id}: ${err.message}`);
    }

    // Delay untuk menghindari spam/banned
    await new Promise(res => setTimeout(res, 1000));
  }

  const report = `⌭  ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴛᴇxᴛ ᴅᴏɴᴇ\n
⌭  sᴜᴄᴄᴇs : ${success} ɢʀᴏᴜᴘ
⌭  ғᴀɪʟᴇᴅ : ${failed} ɢʀᴏᴜᴘ

ᣃ࿈ ʙʀᴏᴀᴅᴄᴀꜱᴛ ʙʏ @faze2high ࿈ᣄ`;

  bot.sendMessage(chatId, report);
});

bot.onText(/^\/del$/, async (msg) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

 // Check if the user is the Owner
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
  // Hanya owner yang bisa broadcast
  if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
                    ]
                ]
            }
        });
        return;
    }

  // Harus reply pesan
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, "❗ Balas pesan yang ingin dihapus dengan perintah /del.");
  }

  try {
    await bot.deleteMessage(chatId, msg.reply_to_message.message_id);
    await bot.deleteMessage(chatId, msg.message_id); // Hapus juga perintah /del agar bersih
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ Gagal menghapus pesan. Mungkin bot bukan admin atau tidak punya izin.");
  }
});

bot.onText(/^\/send(?: (.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const reply = msg.reply_to_message;
    const textToSend = match[1];

    if (reply) {
        // Jika pengguna me-reply pesan dan ketik /send
        return bot.sendMessage(chatId, reply.text || '[Pesan tidak berisi teks]', {
            reply_to_message_id: reply.message_id
        });
    } else if (textToSend) {
        // Jika pengguna ketik /send teks
        return bot.sendMessage(chatId, textToSend);
    } else {
        // Tidak ada input atau reply
        return bot.sendMessage(chatId, '❌ Gunakan perintah /send [teks] atau /send (dengan reply pesan).');
    }
});

bot.onText(/^\/spam(?: (\d+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const reply = msg.reply_to_message;
    const jumlah = parseInt(match[1]);

    if (!reply) {
        return bot.sendMessage(chatId, "❌ Harap reply pesan yang ingin di-spam.");
    }

    if (!jumlah || isNaN(jumlah) || jumlah <= 0 || jumlah > 100) {
        return bot.sendMessage(chatId, "❌ Masukkan jumlah antara 1 - 100.\nContoh: /spam 20");
    }

    const content = reply.text || reply.caption || '[Media tanpa teks]';

    for (let i = 0; i < jumlah; i++) {
        await bot.sendMessage(chatId, content, {
            reply_to_message_id: reply.message_id
        }).catch(e => console.log("Gagal kirim:", e.message));

        await new Promise(resolve => setTimeout(resolve, 300)); // Delay biar gak ke flood
    }
});

bot.onText(/^\/allmember$/, async (msg) => {
    const chatId = msg.chat.id;
    const isGroup = msg.chat.type.includes('group');
    const reply = msg.reply_to_message;

    if (!isGroup) return bot.sendMessage(chatId, "❌ Perintah ini hanya untuk grup.");

    try {
        const admins = await bot.getChatAdministrators(chatId);
        const memberNames = admins.map((admin, i) => {
            const user = admin.user;
            const name = user.first_name + (user.last_name ? " " + user.last_name : "");
            return `${i + 1}. ${name} (${user.username ? "@" + user.username : "tidak ada username"})`;
        });

        const hasil = `👥 Daftar Member Aktif (Admin):\n\n${memberNames.join("\n")}`;

        bot.sendMessage(chatId, hasil, {
            reply_to_message_id: reply?.message_id
        });
    } catch (e) {
        console.error(e);
        bot.sendMessage(chatId, "❌ Gagal mengambil daftar member.");
    }
});

bot.onText(/^\/upch(?: (.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const isReply = msg.reply_to_message;
    const teks = match[1];
    
    // Check if the user is the Owner
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
  // Hanya owner yang bisa broadcast
  if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
                    ]
                ]
            }
        });
        return;
    }

    if (!teks && !isReply) {
        return bot.sendMessage(chatId, "❌ Kirim teks atau reply ke media dengan caption.\n\nContoh:\n/upch Halo channel!\natau\nReply media → /upch Ini caption-nya");
    }

    const opts = {
        caption: teks || (isReply?.caption || ""),
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: "🔗 Join Group", url: "https://t.me/publicdann" },                   
                    { text: "🤖 Bot", url: "https://t.me/CPANELHANZSSBOT" }
                ]
            ]
        }
    };

    try {
        if (isReply?.photo) {
            const fileId = isReply.photo[isReply.photo.length - 1].file_id;
            await bot.sendPhoto(CHANNEL_ID, fileId, opts);
        } else if (isReply?.video) {
            const fileId = isReply.video.file_id;
            await bot.sendVideo(CHANNEL_ID, fileId, opts);
        } else if (isReply?.document) {
            const fileId = isReply.document.file_id;
            await bot.sendDocument(CHANNEL_ID, fileId, opts);
        } else if (teks) {
            await bot.sendMessage(CHANNEL_ID, teks, opts);
        } else {
            await bot.sendMessage(chatId, "❌ Tidak ada format yang didukung untuk dikirim.");
        }

        bot.sendMessage(chatId, "✅ Berhasil mengirim ke channel.");
    } catch (err) {
        console.error(err);
        bot.sendMessage(chatId, "❌ Gagal mengirim ke channel. Pastikan bot adalah admin di channel tujuan.");
    }
});

bot.onText(/^\/tmute(?:\s+)?(.+)?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (msg.chat.type === 'private') return bot.sendMessage(chatId, 'Perintah ini hanya untuk grup.');
  
  // Bot harus admin
  const botMember = await bot.getChatMember(chatId, (await bot.getMe()).id);
  if (!['administrator', 'creator'].includes(botMember.status)) {
    return bot.sendMessage(chatId, 'Bot harus admin untuk memute seseorang.');
  }

  // User yang menjalankan perintah harus admin
  const senderMember = await bot.getChatMember(chatId, fromId);
  if (!['administrator', 'creator'].includes(senderMember.status)) {
    return bot.sendMessage(chatId, 'Kamu harus admin untuk menggunakan perintah ini.');
  }

  let targetUser;
  let durationText;

  if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from;
    durationText = match[1]?.trim();
  } else {
    const args = match[1]?.split(' ') || [];
    const usernameOrId = args[0];
    durationText = args[1];

    // Cari user berdasarkan username
    if (usernameOrId.startsWith('@')) {
      try {
        const admins = await bot.getChatAdministrators(chatId);
        const targetAdmin = admins.find(a => a.user.username?.toLowerCase() === usernameOrId.slice(1).toLowerCase());
        if (targetAdmin) targetUser = targetAdmin.user;
        else return bot.sendMessage(chatId, 'User tidak ditemukan di daftar admin.');
      } catch (e) {
        return bot.sendMessage(chatId, 'Gagal menemukan user.');
      }
    } else {
      return bot.sendMessage(chatId, 'Reply pesan atau mention user dengan benar.');
    }
  }

  const duration = parseDuration(durationText);
  if (!duration) return bot.sendMessage(chatId, 'Format durasi salah. Contoh: 10s, 5m, 2h, 1d');

  const untilDate = Math.floor((Date.now() + duration) / 1000); // dalam detik

  try {
    await bot.restrictChatMember(chatId, targetUser.id, {
      permissions: {
        can_send_messages: false,
        can_send_media_messages: false,
        can_send_polls: false,
        can_send_other_messages: false,
        can_add_web_page_previews: false,
        can_change_info: false,
        can_invite_users: false,
        can_pin_messages: false
      },
      until_date: untilDate
    });

    bot.sendMessage(chatId, `✅ <b>${targetUser.first_name}</b> telah dimute selama <code>${durationText}</code>`, {
      parse_mode: 'HTML'
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, 'Gagal memute user. Mungkin bot bukan admin atau user adalah admin.');
  }
});

bot.onText(/^\/zombies$/, async (msg) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
// Bot harus admin
  const botMember = await bot.getChatMember(chatId, (await bot.getMe()).id);
  if (!['administrator', 'creator'].includes(botMember.status)) {
    return bot.sendMessage(chatId, 'Bot harus admin untuk memute seseorang.');
  }

  // User yang menjalankan perintah harus admin
  const senderMember = await bot.getChatMember(chatId, fromId);
  if (!['administrator', 'creator'].includes(senderMember.status)) {
    return bot.sendMessage(chatId, 'Kamu harus admin untuk menggunakan perintah ini.');
  }

  try {
    await msg.reply("🔍 Memindai akun yang terhapus...");

    const participants = await bot.client.getParticipants(m.chatId, {
      filter: new Api.ChannelParticipantsSearch(""),
    });

    let deletedCount = 0;

    for (const user of participants.participants) {
      const entity = await bot.client.getEntity(user.userId);
      if (entity.className === "User" && entity.deleted) {
        try {
          await bot.client.invoke(
            new Api.channels.EditBanned({
              channel: m.chatId,
              participant: entity.id,
              bannedRights: new Api.ChatBannedRights({
                untilDate: 0,
                viewMessages: true,
              }),
            })
          );
          deletedCount++;
        } catch (err) {
          console.log("Gagal kick:", entity.id, err.message);
        }
      }
    }

    await msg.reply(`✅ Selesai! Ditemukan dan dikeluarkan ${deletedCount} akun terhapus.`);
  } catch (e) {
    console.error(e);
    msg.reply("❌ Terjadi kesalahan saat menghapus akun terhapus.");
  }
});

bot.onText(/^\/hidetag(?:\s+([\s\S]+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1] || '';

  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, 'Perintah ini hanya bisa digunakan di grup.');
  }

  try {
    const members = await bot.getChatAdministrators(chatId);

    const tags = members.map(member => {
      const user = member.user;
      if (user.username) {
        return `@${user.username}`;
      } else {
        // Gunakan mention tersembunyi jika tidak ada username
        const name = user.first_name?.replace(/[\*_`]/g, '') || 'user';
        return `[${name}](tg://user?id=${user.id})`;
      }
    });

    const message = `✉️ Pesan:\n${text}\n\n👤 Tag All\n${tags.join(' ')}`;

    await bot.sendMessage(chatId, message, {
      parse_mode: 'Markdown'
    });
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, 'Gagal mengambil daftar member atau mengirim mention.');
  }
});

bot.onText(/^\/promote(?:\s+(.*))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  // Pastikan bot adalah admin
  const botMember = await bot.getChatMember(chatId, (await bot.getMe()).id);
  if (!['administrator', 'creator'].includes(botMember.status)) {
    return bot.sendMessage(chatId, '❌ Bot harus admin untuk mempromosikan seseorang.');
  }

  // Pastikan pengirim perintah adalah admin
  const senderMember = await bot.getChatMember(chatId, fromId);
  if (!['administrator', 'creator'].includes(senderMember.status)) {
    return bot.sendMessage(chatId, '❌ Kamu harus admin untuk menggunakan perintah ini.');
  }

  // Pastikan reply ke pesan user yang ingin dipromosikan
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '❌ Harap reply ke pesan user yang ingin dipromosikan.');
  }

  const targetUserId = msg.reply_to_message.from.id;

  try {
    await bot.promoteChatMember(chatId, targetUserId, {
      can_change_info: false,
      can_post_messages: true,
      can_edit_messages: true,
      can_delete_messages: false,
      can_invite_users: true,
      can_restrict_members: false,
      can_pin_messages: true,
      can_promote_members: false,
      can_manage_video_chats: true,
    });

    const rank = match[1]?.trim();
    const infoRank = rank ? ` dengan jabatan: *${rank}*` : "";

    await bot.sendMessage(
      chatId,
      `✅ Berhasil mempromosikan user${infoRank}.`,
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    console.error(err);
    await bot.sendMessage(chatId, "❌ Gagal mempromosikan user. Pastikan bot memiliki izin yang cukup.");
  }
});

bot.onText(/^\/demote(?:\s+)?(.+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;
  const isGroup = msg.chat.type.endsWith("group");
  const senderId = msg.from.id;

  // Bot harus admin
  const botMember = await bot.getChatMember(chatId, (await bot.getMe()).id);
  if (!['administrator', 'creator'].includes(botMember.status)) {
    return bot.sendMessage(chatId, 'Bot harus admin untuk memute seseorang.');
  }

  // User yang menjalankan perintah harus admin
  const senderMember = await bot.getChatMember(chatId, fromId);
  if (!['administrator', 'creator'].includes(senderMember.status)) {
    return bot.sendMessage(chatId, 'Kamu harus admin untuk menggunakan perintah ini.');
  }

  // Ambil reply message
  const reply_message = msg.reply_to_message;
  let targetUserId;

  if (reply_message) {
    targetUserId = reply_message.from.id;
  } else if (match[1]) {
    const username = match[1].replace("@", "").trim();
    try {
      const user = await bot.getChatMember(chatId, username);
      targetUserId = user.user.id;
    } catch (err) {
      return bot.sendMessage(chatId, "❌ Tidak bisa menemukan user dengan username itu.");
    }
  }

  if (!targetUserId) {
    return bot.sendMessage(chatId, "❌ Harap reply pesan atau tag username yang valid.");
  }

  try {
    await bot.promoteChatMember(chatId, targetUserId, {
      can_change_info: false,
      can_post_messages: false,
      can_edit_messages: false,
      can_delete_messages: false,
      can_invite_users: false,
      can_restrict_members: false,
      can_pin_messages: false,
      can_promote_members: false
    });
    await bot.sendMessage(chatId, "✅ Berhasil menghapus status admin target.");
  } catch (e) {
    console.error(e);
    await bot.sendMessage(chatId, "❌ Gagal mendemote. Mungkin user bukan admin atau bot tidak punya akses.");
  }
});

bot.onText(/^\/ban(?:\s+)?(.+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  const botMember = await bot.getChatMember(chatId, (await bot.getMe()).id);
  if (!['administrator', 'creator'].includes(botMember.status)) {
    return bot.sendMessage(chatId, '❌ Bot harus admin untuk membanned seseorang.');
  }

  const senderMember = await bot.getChatMember(chatId, fromId);
  if (!['administrator', 'creator'].includes(senderMember.status)) {
    return bot.sendMessage(chatId, '❌ Kamu harus admin untuk menggunakan perintah ini.');
  }

  let targetUserId;
  let alasan = "Tanpa alasan.";

  if (msg.reply_to_message) {
    targetUserId = msg.reply_to_message.from.id;
    alasan = match[1] || "Tanpa alasan.";
  } else if (match[1]) {
    const text = match[1];
    if (text.startsWith("@")) {
      return bot.sendMessage(chatId, "❌ Tidak bisa mem-ban user hanya dengan username. Harap reply pesannya.");
    } else {
      targetUserId = parseInt(text);
    }
  }

  if (!targetUserId) {
    return bot.sendMessage(chatId, "❌ Harap reply pesan atau berikan user ID untuk mem-ban.");
  }

  try {
    await bot.banChatMember(chatId, targetUserId);
    await bot.sendMessage(chatId, `✅ User berhasil di-ban.\n📝 Alasan: ${alasan}`);
  } catch (err) {
    console.error(err);
    await bot.sendMessage(chatId, "❌ Gagal mem-ban user. Pastikan bot punya izin yang cukup.");
  }
});

bot.onText(/\/info/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;

  const senderName = user.username || 'unknown';
  const id = user.id;

  try {
    // Ambil foto profil pengguna jika ada
    const photos = await bot.getUserProfilePhotos(user.id, { limit: 1 });
    let profilePic;
    if (photos.total_count > 0) {
      const fileId = photos.photos[0][0].file_id;
      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const response = await fetch(fileUrl);
      const buffer = await response.arrayBuffer();
      profilePic = await loadImage(Buffer.from(buffer));
    }

    // Buat kanvas
    const canvas = createCanvas(1280, 853); // Ukuran template Anda
    const ctx = canvas.getContext('2d');

    // Muat template
    const template = await loadImage('./template.png');
    ctx.drawImage(template, 0, 0, canvas.width, canvas.height);

    // Tambahkan foto profil (berbentuk kotak, di tengah)
    if (profilePic) {
      const profileX = 100; // Posisi X foto profil
      const profileY = 340; // Posisi Y foto profil
      const profileSize = 160; // Ukuran kotak foto profil
      ctx.drawImage(profilePic, profileX, profileY, profileSize, profileSize);
    }

    // Tambahkan teks dengan posisi yang sesuai
    ctx.fillStyle = '#000000';
    ctx.font = '36px Arial';
    ctx.textAlign = 'left';

    const textPositions = {
      "Nama": { x: 580, y: 300 },
      "User ID": { x: 580, y: 365 },
      "User Name": { x: 580, y: 430 },
      "Tanggal": { x: 580, y: 495 },
    };

    const textData = {
      "Nama": user.first_name || 'Unknown',
      "User ID": id,
      "User Name": `@${senderName}`,
      "Tanggal": moment().format('YYYY-MM-DD'),
    };

    for (const [label, value] of Object.entries(textData)) {
      const { x, y } = textPositions[label];
      ctx.fillText(`${label} : ${value}`, x, y);
    }

    // Hasilkan gambar sebagai buffer
    const finalBuffer = canvas.toBuffer('image/png');

    // Kirim hasil ke pengguna dengan tombol
    const hasilFinal = `
👤 Nama: ${user.first_name || 'Unknown'}
🆔 ID: ${id}
🌐 Username: @${senderName}
🔗 Link: https://t.me/${senderName}
`;

    bot.sendPhoto(chatId, finalBuffer, {
      caption: hasilFinal,
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔗 ROOM #1', url: 'https://t.me/publicdann' },
            { text: '🔗 ROOM #2', url: 'https://t.me/xppublic2' },
          ],
          [
            { text: '👤 Developer', url: 'https://t.me/faze2high' },
          ],
        ],
      },
    });

  } catch (err) {
    console.error('Error saat membuat ID Card:', err);
    bot.sendMessage(chatId, 'Gagal membuat ID Card. Silakan coba lagi.');
  }
});

bot.onText(/\/id/, async (msg) => {
  const chatId = msg.chat.id;
  const user = msg.from;
  const senderName = `@${user.username || 'unknown'}`;
  const sender = user.username || 'unknown';
  const id = user.id;

  try {
    const canvas = createCanvas(800, 500);
    const ctx = canvas.getContext('2d');

    // Pastikan path template benar!
    const template = await loadImage('./assets/template.png');
    ctx.drawImage(template, 0, 0, canvas.width, canvas.height);

    // Font dan Warna
    ctx.fillStyle = '#000';
    ctx.font = 'bold 30px Arial';

    // Nama
    ctx.fillText(`: ${user.first_name}`, 220, 180);

    // User ID
    ctx.fillText(`: ${user.id}`, 220, 230);

    // Username
    ctx.fillText(`: @${user.username || '-'}`, 220, 280);

    // Tanggal
    ctx.fillText(`: ${moment().format('YYYY-MM-DD')}`, 220, 330);

    // Convert ke buffer
    const buffer = canvas.toBuffer('image/png');

    const hasilFinal = `
👤 Nama: ${user.first_name}
🆔 ID: ${id}
🌐 Username: ${senderName}
🔗 Link: https://t.me/${sender}
`;

    // Kirim ke user
    bot.sendPhoto(chatId, buffer, {
      caption: hasilFinal,
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔗 ROOM #1', url: 'https://t.me/publicdann' },
            { text: '🔗 ROOM #2', url: 'https://t.me/xppublic2' }
          ],
          [
            { text: '👤 Developer', url: 'https://t.me/faze2high' }
          ]
        ]
      }
    });

  } catch (err) {
    console.error('❌ Error saat membuat ID Card:', err);
    bot.sendMessage(chatId, '❌ Gagal membuat ID Card. Cek apakah file `template.png` ada di folder `assets`.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listadmin
bot.onText(/\/listhama/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/faze2high' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut list admin :\n\n";
        for (let user of users) {
            let u = user.attributes;
            if (u.root_admin) {
                messageText += `🆔 ID: ${u.id} - 🌟 Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
                messageText += `${u.username}\n`;
                messageText += `${u.first_name} ${u.last_name}\n\n`;
                messageText += 'Create By Faze';
            }
        }
        messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total Admin: ${res.meta.pagination.count}`;
        const keyboard = [
            [
                { text: 'BACK', callback_data: JSON.stringify({ action: 'back', page: parseInt(res.meta.pagination.current_page) - 1 }) },
                { text: 'NEXT', callback_data: JSON.stringify({ action: 'next', page: parseInt(res.meta.pagination.current_page) + 1 }) }
            ]
        ];
        bot.sendMessage(chatId, messageText, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
        //▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// batas akhir
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
  bot.onText(/\/panel/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '8466831007'; // Ganti dengan ID pemilik bot 
    const text12 = `*Hii @${sender} 👋*  
Tutorial createpanel
Ex: /unli nama,idtelegram
Ex: /unli faze,8466831007
[ Cek Id Telegram With Command /cekid ]

Ingin memiliki akses reseller-admin? buy di @faze2high`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/faze2high' }, { text: '👤 Buy Admin', url: 'https://t.me/faze2high' }],
                [{ text: '🇲🇨 Buy ubot', url: 'https://t.me/faze2high' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});      