const config = {
  token: 'TOKEN_BOT_LU',
  adminId: 'ID_LU', 
  pp: 'https://c.termai.cc/i15/Yar0E.jpg',
urladmin: 'https://t.me/Tr4cyz_Scott',
  pp: 'https://c.termai.cc/i15/Yar0E.jpg',
  channelprib: 'https://t.me/',
    //SERVER 1
  domain: 'domain_lu', // Isi dengan domain yang digunakan
  plta: 'plta_lu', // Isi dengan nilai plta yang sesuai
  pltc: 'pltc_lu', // Isi dengan nilai pltc yang sesuai
  
  //SERVER 2
  domainV2: 'https://', // Isi dengan domain yang digunakan
  pltaV2: 'ptla_---', // Isi dengan nilai plta yang sesuai
  pltcV2: 'ptlc_---', // Isi dengan nilai pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '17'
};

module.exports = config;